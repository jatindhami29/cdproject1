class Test {
    public static void main(String[] args) {
        int num = "text";  // assigning string to int
    }
}
